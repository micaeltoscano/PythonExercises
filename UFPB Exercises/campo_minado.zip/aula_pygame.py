import pygame
import random

pygame.init()

# Cria tuplas para cores
amarelo = (255, 255, 0)
azul =  (0, 0, 255)
azul_claro = (100, 149, 237)
azul_escuro = (0, 0, 128)
azul_petroleo = (0, 128, 128)
azul_piscina = (0, 255, 255)
branco = (255, 255, 255)
cinza = (128, 128, 128)
fucsia = (255, 0, 255)
marrom = (128, 0, 0)
roxo = (128, 0, 128)
verde = (0, 128, 0)
verde_claro = (0, 255, 0)
verde_oliva = (128, 128, 0)
vermelho = (255, 0, 0)
prateado = (192, 192, 192)
preto = (0, 0, 0)

# Cria uma tela
screen = pygame.display.set_mode( (640, 480) )
pygame.display.set_caption("PyGame")
screen.fill(verde_oliva) 
pygame.display.update()

jogo = True
while jogo:
    # Trata os eventos gerados pelo Pygame
    for evento in pygame.event.get():        
        print(evento.type)
                
        # Evento que fecha a janela
        if (evento.type == pygame.QUIT):
            jogo = False
            
        if (evento.type == pygame.KEYDOWN and evento.key == pygame.K_UP):
        	# Desenha retangulo
            pygame.draw.rect(screen, verde, (0, 0, 200, 200), 0) 
        
        if (evento.type == pygame.KEYDOWN and evento.key == pygame.K_DOWN):
	        # Desenha retangulo
            pygame.draw.rect(screen, amarelo, (0, 0, 200, 200), 0) 
        
        if (evento.type == pygame.KEYDOWN and evento.key == pygame.K_LEFT):
    		# Desenha retangulo    
            pygame.draw.rect(screen, azul, (0, 0, 200, 200), 0) 
    		
        if (evento.type == pygame.KEYDOWN and evento.key == pygame.K_RIGHT):
	        # Desenha retangulo
            pygame.draw.rect(screen, branco, (0, 0, 200, 200), 0) 

        # Pressionamento da Tecla 1    
        if (evento.type == pygame.KEYDOWN and evento.key == pygame.K_1):
            print("Tecla 1")
            
            largura = random.randint(0,50)
            altura = random.randint(0,50)
            x = random.randint(0,400)
            y = random.randint(0,400)

            pygame.draw.rect(screen, preto, (x, y, largura, altura), 0) 
            
        pygame.display.update()                 
      

pygame.quit()
